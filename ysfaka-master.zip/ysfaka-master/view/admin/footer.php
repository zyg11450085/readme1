
    </div>
    </div>
    </div>
    </div>
    </div>
    <div id="footer">
        &copy;&nbsp;2018&nbsp;
        <?php echo $this->
            config['sitename']?>&nbsp;Powered by 云尚创想 <a href="http://www.yunscx.com" target="_blank">www.yunscx.com</a>
    </div>
    <div class="modal" id="waModal" role="dialog" aria-labelledby="waModalLable">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">
                            &times;
                        </span>
                    </button>
                    <h4 class="modal-title">
                        Modal title
                    </h4>
                </div>
                <div class="modal-body">
                </div>
            </div>
        </div>
    </div>
    </body>
    
    </html>